#include <QCoreApplication>
#include "time.h"
#include <QDebug>


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Time s(15, 30), b(17, 00);

    int min = b - s;
    qDebug("количество минут  %d", min);

    return a.exec();
}
