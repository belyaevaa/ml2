#ifndef TIME_H
#define TIME_H


class Time
{
public:
    Time();
    Time(int h, int m);

    void print();
    int operator -(Time t);
    Time operator +(int t);

private:
    int hours; int minutes;

};

#endif // TIME_H
