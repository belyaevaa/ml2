#include "time.h"
#include <qDebug>

Time::Time()
{

}

Time::Time(int h, int m)
{
    if(m >= 60){
        int td = m / 60;
        h += td;
        m -= td * 60;
    }
    if(h<24)
        this->hours = h;
    else
        this->hours = h-24 *(h/24);

    this->minutes = m;
}

void Time::print()
{
    qDebug("%d,%d", this->hours, this->minutes);
}

Time Time::operator +(int t)
{
    return Time(this->hours, t+this->minutes);
}

int Time::operator-(Time t)
{
   int n;
   n = this->hours-t.hours >0 ? this->hours-t.hours : 24 + this->hours-t.hours;
   return (n * 60 +(this->minutes-t.minutes));
}
